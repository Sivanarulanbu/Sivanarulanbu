# Do Django signals run in the same thread as the caller?

# Yes, Django signals run in the same thread as the caller. This means that 
# if a signal is emitted from a particular thread, the signal handlers will also run in that same thread.

import threading
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.test import TestCase
from django.contrib.auth.models import User

current_thread_id = threading.get_ident()

@receiver(post_save, sender=User )
def user_saved_handler(sender, instance, created, **kwargs):
    print(f"Signal executed in thread: {threading.get_ident()}")
    assert threading.get_ident() == current_thread_id, "Signal is not running in the same thread"

class SignalThreadTest(TestCase):
    def test_signal_thread_execution(self):
        print(f"Current thread before saving user: {current_thread_id}")
        user = User(username='testuser')
        user.save()  

# the signal handler matches the current thread ID.

