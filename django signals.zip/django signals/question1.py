# Question 1: Are Django signals executed synchronously or asynchronously?

# Django signals are executed synchronously. This means that when a signal is sent,
# the connected signal handlers are executed immediately in the same thread.

from django.db.models.signals import post_save
from django.dispatch import receiver
from django.test import TestCase
from django.contrib.auth.models import User

@receiver(post_save, sender=User )
def user_saved_handler(sender, instance, created, **kwargs):
    print(f"User  saved: {instance.username}")

class SignalTest(TestCase):
    def test_signal_execution(self):
        print("Before saving user")
        user = User(username='testuser')
        user.save()  
        print("After saving user")

