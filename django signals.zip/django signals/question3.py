# Do Django signals run in the same database transaction as the caller? 

# Django signals run in the same database transaction as the caller.
# This means that if the caller is within a transaction, the signal handlers will also be part of that transaction.

from django.db import transaction
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.test import TestCase
from django.contrib.auth.models import User
from django.db import IntegrityError

@receiver(post_save, sender=User )
def user_saved_handler(sender, instance, created, **kwargs):
    # the same username exception
    try:
        User.objects.create(username=instance.username)
    except IntegrityError:
        print("IntegrityError raised, indicating that the signal is in the same transaction.")

class SignalTransactionTest(TestCase):
    def test_signal_transaction(self):
        with transaction.atomic():
            user = User(username='testuser')
            user.save() 

