from tkinter import *
from tkinter import messagebox
from PIL import ImageTk, Image
window = Tk()
window.geometry("1000x550")
img = ImageTk.PhotoImage(Image.open("jarvis2.png"))
panel = Label(window, image = img)
panel.pack(side = "bottom", fill = "both", expand = "yes")
myLabel1=Label(window,text="JARVIS",fg="white",bg="black",font=("Dungeon","20","bold"))
myLabel1.place(x=445,y=258)
e1= Entry(window, width=30,borderwidth=10)
e1.place(x=750,y=225)
e2 = Entry(window, width=30,borderwidth=10)
e2.place(x=750,y=275)
def login():
    username=e1.get()
    password=e2.get()
    if(username=="" and password==""):
        messagebox.showinfo("","enter the username & password")
    elif(username=="admin" and password=="123"):
        messagebox.showinfo("","login success")
        window1=Tk()
        window1.geometry("825x425")
        window1.title("Jarvis")
        def convey():
            convey = "You  : " + e3.get()
            txt.insert(END,convey)
            user = e3.get().lower()
            if(user=="hello"):
                txt.insert(END, "   \njarvis:  Hi\n")
            elif (user == "hi!" or user == "hi" or user == "Hi"):
                txt.insert(END, "   \njarvis:  Hello,I'm Jarvis,How can I help you?\n")
            elif (e3.get() == "how are you?"):
                txt.insert(END, "   \njarvis:  fine! and what about you?\n")
            elif (user == "fine" or user == "i am good" or user == "i am doing good\n"):
                txt.insert(END, "   \njarvis:  Sounds good,how can I help you?.\n")
            elif (user == "what is tkinter?" or user == "What is tkinter?" or user == "Do you know about tkinter?\n"):
                txt.insert(END, "   \njarvis:  Tkinter is a GUI library in Python that is a fast and easy way to create GUI applications.\n")
            elif (user == "Thank you!jarvis" or user == "thank you" or user == "Thank you"):
                txt.insert(END, "   \njarvis:  you're welcome ever\n")
            else:
                txt.insert(END, "   \njarvis: Sorry! I dind't got you\n")
            e3.delete(0, END)

        myLabel3 = Label(window1, text="JARVIS", fg="black", bg="white", font=("dungeon", "18", "bold"))
        myLabel3.grid(row=0, column=1)
        myLabel2 = Label(window1, text="Type Something", padx=1, pady=1, fg="dark green", bg="white",
                         font=("Ifinetalic", "12", "bold"))
        myLabel2.grid(row=3, column=0)
        txt = Text(window1, width=100, font="LCDMono2", bg="#34ebe5")
        txt.grid(row=2, column=0, columnspan=3)
        e3= Entry(window1, width=60, borderwidth=10)
        e3.grid(row=3, column=1)
        convey=Button(window1,text="send",fg="black",bg="sky blue",font=("opensans","12","bold"),command=convey)
        convey.grid(row=3,column=2)
        window1.mainloop()
    else:
        messagebox.showinfo("","incorrect usename and password")

button1=Button(window,text="sign in",padx=2,pady=2,command=login,fg="white",bg="black",font=("dungeon","12","bold"))
button1.place(x=810,y=325)
window.mainloop()
